export type Styles = {
  'slot-machine': string;
};

export type ClassNames = keyof Styles;

declare const styles: Styles;

export default styles;
