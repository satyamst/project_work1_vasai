const nanoid = {
  nanoid: () => '',
};
export default nanoid;
