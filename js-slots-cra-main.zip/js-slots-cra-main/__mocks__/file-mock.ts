const fileMock = 'test-file-stub';
export default fileMock;
