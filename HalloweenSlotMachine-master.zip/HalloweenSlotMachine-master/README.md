# HalloweenSlotMachine
Simple Halloween Slot Machine made using jQuery-jSlots
